<template>
  <Landing />
</template>

<script setup>
  import Landing from '@/components/Landing.vue'
</script>
