<template>
    <div class="text-h2">
        This is about.
    </div>
</template>